<?php
    error_reporting(0);
    include 'db.php';

    // Ambil kontak admin
    $kontak = mysqli_query($conn, "SELECT admin_telp, admin_email, admin_address FROM tb_admin WHERE admin_id = 2");
    $a = mysqli_fetch_object($kontak);

    // Cek ID Gambar
    $image_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

    // Ambil data gambar
    $produk = mysqli_query($conn, "SELECT * FROM tb_image WHERE image_id = '$image_id' ");
    $p = mysqli_fetch_object($produk);

    if (!$p) {
        echo "Data gambar tidak ditemukan.";
        exit;
    }

    // Sementara gunakan user_id tetap (bisa disesuaikan jika ada login)
    $user_id = 1;

    // LIKE: Proses Like saat tombol diklik
    if (isset($_POST['like'])) {
        $cek = mysqli_query($conn, "SELECT * FROM likes WHERE image_id = '$image_id' AND user_id = '$user_id'");
        if (mysqli_num_rows($cek) == 0) {
            mysqli_query($conn, "INSERT INTO likes (image_id, user_id) VALUES ('$image_id', '$user_id')");
        }
        header("Location: detail-image.php?id=$image_id");
        exit;
    }

    // KOMENTAR: Proses Kirim Komentar
    if (isset($_POST['submit_comment'])) {
        $comment = mysqli_real_escape_string($conn, $_POST['comment']);
        if (!empty($comment)) {
            mysqli_query($conn, "INSERT INTO comments (image_id, user_id, comment) VALUES ('$image_id', '$user_id', '$comment')");
        }
        header("Location: detail-image.php?id=$image_id");
        exit;
    }

    // Hitung total Like
    $like_result = mysqli_query($conn, "SELECT COUNT(*) as total FROM likes WHERE image_id = '$image_id'");
    $like_count = mysqli_fetch_assoc($like_result)['total'];

    // Ambil daftar komentar
    $comment_result = mysqli_query($conn, "SELECT * FROM comments WHERE image_id = '$image_id' ORDER BY created_at DESC");
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Galeri Foto</title>
<link rel="stylesheet" type="text/css" href="css/style.css">
</head>

<body>
    <!-- header -->
    <header>
        <div class="container">
            <h1><a href="index.php">Galeri Foto</a></h1>
            <ul>
                <li><a href="galeri.php">Galeri</a></li>
                <li><a href="registrasi.php">Registrasi</a></li>
                <li><a href="login.php">Login</a></li>
            </ul>
        </div>
    </header>

    <!-- search -->
    <div class="search">
        <div class="container">
            <form action="galeri.php">
                <input type="text" name="search" placeholder="Cari Foto" value="<?php echo $_GET['search'] ?>" />
                <input type="hidden" name="kat" value="<?php echo $_GET['kat'] ?>" />
                <input type="submit" name="cari" value="Cari Foto" />
            </form>
        </div>
    </div>

    <!-- product detail -->
    <div class="section">
        <div class="container">
            <h3>Detail Foto</h3>
            <div class="box">
                <div class="col-2">
                    <img src="foto/<?php echo $p->image ?>" width="100%" />
                </div>
                <div class="col-2">
                    <h3><?php echo $p->image_name ?><br />
                        Kategori : <?php echo $p->category_name  ?>
                    </h3>
                    <h4>Nama User : <?php echo $p->admin_name ?><br />
                        Upload Pada Tanggal : <?php echo $p->date_created  ?></h4>
                    <p>Deskripsi :<br />
                        <?php echo $p->image_description ?>
                    </p>

                    <!-- Like -->
                    <form method="post" style="margin-top: 20px;">
                        <input type="hidden" name="like" value="1">
                        <button type="submit" style="padding: 10px 20px;">❤️ Like (<?php echo $like_count ?>)</button>
                    </form>
                </div>
            </div>

            <!-- Komentar -->
            <div class="box" style="margin-top: 40px;">
                <h3>Komentar</h3>
                <form method="post">
                    <textarea name="comment" placeholder="Tulis komentar di sini..." required style="width:100%; height:100px;"></textarea><br>
                    <button type="submit" name="submit_comment" style="margin-top:10px;">Kirim Komentar</button>
                </form>

                <div style="margin-top: 30px;">
                    <?php while ($row = mysqli_fetch_assoc($comment_result)): ?>
                        <div style="margin-bottom: 15px; border-bottom: 1px solid #ccc; padding-bottom: 10px;">
                            <strong>User <?php echo $row['user_id'] ?>:</strong><br>
                            <?php echo nl2br(htmlspecialchars($row['comment'])) ?><br>
                            <small><em><?php echo $row['created_at'] ?></em></small>
                        </div>
                    <?php endwhile; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- footer -->
    <footer>
    <div class="container">
            <small>&copy; Copyright <strong>Galeri Foto</strong>. All Rights Reserved</small>
        </div>
    </footer>
</body>
</html>